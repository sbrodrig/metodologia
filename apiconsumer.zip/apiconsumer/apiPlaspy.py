import urllib
import inspect
import settings_local

class PRequest:
    Account = settings_local.account
    ApiKey = settings_local.apiKey
    IdDevice = 0
    LastPosition = settings_local.LastPosition
    StartUTC = '0'#str(datetime.datetime.utcnow() - timedelta(hours=12))
    EndUTC = '0'#str(datetime.datetime.utcnow())
    def props(self):
        pr = {}
        for name in dir(self):
            value = getattr(self, name)
            if not name.startswith('__') and not inspect.ismethod(value):
                pr[name] = value
        return pr
    def GetParamsRequest(self):
        return urllib.parse.urlencode(self.props())
    def GetXMLRequest(self):
        request="<PRequest>"
        for name in dir(self):
            value = getattr(self, name)
            if not name.startswith('__') and not inspect.ismethod(value):
                request+="<"+name +">" + str(value) + "</"+name +">"
        request+= "</PRequest>"
        return request