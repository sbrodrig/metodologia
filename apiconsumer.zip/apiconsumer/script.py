from urllib.request import Request
from apiPlaspy import PRequest
from datetime import timedelta
import csv
import urllib
import json
import settings_local
import datetime

request= PRequest()

print("ingrese fecha inicial")
fecha = input("YYYY-MM-DD:  ")
print("ingrese mes final")
final_month = int(input("MM:  "))
idsfile = fecha
#hora = '00:00:00'
hora = '23:00:00'
nameRsp = 'response_'+idsfile+'.csv'
nameError = 'error_'+idsfile+'.csv'

fecha = fecha.split('-')
hora = hora.split(':')

#crea el archivo para guardar las respuestas
with open(nameRsp, 'a+', newline='') as csvOut:
	responsewriter = csv.writer(csvOut, delimiter=',')
	responsewriter.writerow(['id','DateTime', 'Latitude', 'Longitude','Speed'])#,'Course','Battery'])

	csvError = open(nameError,'w')
	errorwriter = csv.writer(csvError, delimiter=',')
	errorwriter.writerow(['ID'])

	#Recorre los ids del archivo
	csvIn = open('idsRESULTANTES.csv')
	for line in csvIn.readlines():
		id = line[:len(line)-1]
		request.IdDevice = id

		YEAR = int(fecha[0])
		MONTH = int(fecha[1])
		DAY = int(fecha[2])
		HOUR = int(hora[0])
		MIN = int(hora[1])
		SEC = int(hora[2])

		d = datetime.datetime(
			YEAR,
			MONTH,
			DAY,
			HOUR,
			MIN,
			SEC
		)

		request.StartUTC = str(d)
		request.EndUTC = str(d + timedelta(hours=1))
		flagSuccess = False
		idErrorCounter = 0
		print('\n################################# START id '+str(request.IdDevice)+' #################################\n')
		#itera por fecha y hora
		while d.month != final_month:
			print('************ Date '+request.StartUTC+'+1H ************')
			try:
				f = urllib.request.urlopen(settings_local.APIURL + "?" + request.GetParamsRequest())
				rsp = json.loads(f.read())
				if len(rsp) > 0:
					for point in rsp:
						responsewriter.writerow([
							id,
							point.get('DateTime'),
							point.get('Latitude'),
							point.get('Longitude'),
							point.get('Speed'),
							])
					print('Success')
					flagSuccess=True
				elif not flagSuccess:
					print('Success... Vacio\nSaltando a siguiente mes')
					last_month = d.month
					while last_month == d.month:
						d = d + timedelta(hours=24)
					d = d - timedelta(hours=1)
			except:
				idErrorCounter += 1
				if idErrorCounter % 24 == 0:
					"""opt = input("desea continuar con este id? (y,n)")
					if opt == 'n':"""
					break
				errorwriter.writerow([id])
				print('Error')

			# cambia la hora +1
			d = d + timedelta(hours=1)
			request.StartUTC = str(d)
			request.EndUTC = str(d + timedelta(hours=1))
		print('\n################################# END  #################################\n')
	csvError.close()