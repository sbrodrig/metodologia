from urllib.request import Request
from apiPlaspy import PRequest
from datetime import timedelta
import csv
import urllib
import json
import settings_local
import datetime

request= PRequest()

while True:
	print("Press Ctrl+c to exit")
	if request.LastPosition:
		print("Ingrese la fecha final:  AAAA-MM-DD")
	else:
		print("Ingrese la fecha inicial:  AAAA-MM-DD")
	fecha = input()
	if request.LastPosition:
		print("Ingrese la hora final:  HH:MM:SS")
	else:
		print("Ingrese la hora inicial:  HH:MM:SS")
	hora = input()

	nameRsp = 'response_'+fecha.replace("-","_")+'__'+hora.replace(":","_")+'.csv'
	nameError = 'error_'+fecha.replace("-","_")+'__'+hora.replace(":","_")+'.csv'

	fecha = fecha.split('-')
	hora = hora.split(':')

	YEAR = int(fecha[0])
	MONTH = int(fecha[1])
	DAY = int(fecha[2])
	HOUR = int(hora[0])
	MIN = int(hora[1])
	SEC = int(hora[2])

	d = datetime.datetime(
		YEAR,
		MONTH,
		DAY,
		HOUR,
		MIN,
		SEC
	)

	#si LastPosition es True se define un rango de 12 horas antes de la hora de Settings
	if request.LastPosition:
		request.StartUTC = str(d - timedelta(hours=12))
		request.EndUTC = str(d)
	#si LastPosition es False se define un rango de 1 hora después de la hora de Settings
	else:
		request.StartUTC = str(d)
		request.EndUTC = str(d + timedelta(hours=1))

	print("Desea proceso automatico de 24H de consulta? (y/n)")
	auto = input()
	if auto == 'y' or auto == 'Y' or auto == 'yes' or auto == 'YES':
		auto = True
	else:
		auto = False

	if auto:
		#crea el archivo para guardar las respuestas
		with open(nameRsp, 'w', newline='') as csvOut:
			responsewriter = csv.writer(csvOut, delimiter=';')
			responsewriter.writerow(['id','DateTime', 'Latitude', 'Longitude','Speed'])#,'Course','Battery'])

			csvError = open(nameError,'w')
			errorwriter = csv.writer(csvError, delimiter=';')
			errorwriter.writerow(['ID'])

			#Recorre los ids del archivo
			with open('ids.csv') as csvIn:
				reader = csv.DictReader(csvIn)
				#itera por id en csv
				for row in reader:
					print('\n################################# START id '+str(request.IdDevice)+' #################################\n')
					#itera por fecha y hora
					for n in range(0, 24):
						id = row['\ufeffID']
						request.IdDevice = id
						print('************ Date '+str(d)+'+1H ************')
						try:
							f = urllib.request.urlopen(settings_local.APIURL + "?" + request.GetParamsRequest())
							rsp = json.loads(f.read())
							for point in rsp:
								responsewriter.writerow([
									id,
									point.get('DateTime'),
									point.get('Latitude'),
									point.get('Longitude'),
									point.get('Speed'),
									#point.get('Course'),
									#point.get('Battery'),
									])
							print('Success')
						except:
							errorwriter.writerow([id])
							print('Error')
						# cambia la hora +1
						d = d + timedelta(hours=1)
						request.StartUTC = str(d)
						request.EndUTC = str(d + timedelta(hours=1))
					print('\n################################# END  #################################\n')
			csvError.close()
	else:
		#crea el archivo para guardar las respuestas
		print('************************START************************')
		with open(nameRsp, 'w', newline='') as csvOut:
			responsewriter = csv.writer(csvOut, delimiter=';')
			responsewriter.writerow(['id','DateTime', 'Latitude', 'Longitude','Speed','Course','Battery'])

			csvError = open(nameError,'w')
			errorwriter = csv.writer(csvError, delimiter=';')
			errorwriter.writerow(['ID'])

			#Recorre los ids del archivo
			with open('ids.csv') as csvIn:
				reader = csv.DictReader(csvIn)
				for row in reader:
					id = row['\ufeffID']
					request.IdDevice = id
					print('Get JSON id: '+request.IdDevice)
					try:
						f = urllib.request.urlopen(settings_local.APIURL + "?" + request.GetParamsRequest())
						rsp = json.loads(f.read())
						for point in rsp:
							responsewriter.writerow([
								id,
								point.get('DateTime'),
								point.get('Latitude'),
								point.get('Longitude'),
								point.get('Speed'),
								point.get('Course'),
								point.get('Battery'),
								])
						print('Success id '+id)
					except:
						errorwriter.writerow([id])
						print('Error id '+id)

			csvError.close()

		print('*************************END*************************')