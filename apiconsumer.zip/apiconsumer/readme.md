Simple Consumer API plaspy
==========================

This is a simple project to consume an Plaspy's Traking API, and analyze the received data to 
stimate road traffic by GPS points.

Configuration 
--------------------

Before execute it's necesary to define the main values in a file called *settings_local.py*, and provide a csv file called *ids.csv* with a single ID colum.

The main values are:

+ **apiKey** (String)
+ **account** (String)
+ **APIURL** (String)
+ **LastPosition** (Boolean)


Execute
--------------------

To execute just run:

+ python3 consumer.py


Result
--------------------

The result is store in 2 files *response_AAAA_MM_DD__HH_MM_SS.csv* and *error_AAAA_MM_DD__HH_MM_SS.csv*. the first store each GPS point with their attributes, and the second file store the ids which happen an error.