import csv 

archivos = ["idsNUEVOS.csv", "ids.csv"]

lista_idNUEVOS = []
lista_id = []
lista_idRESULT = []

f = open("idsNUEVOS.csv")
f1 = f.readlines()
for line in f1:
	lista_idNUEVOS.append(line)


f2 = open("ids.csv")
f3 = f2.readlines()
for line in f3:
	lista_id.append(line)

f.close()
f2.close()

f_new = open("idsRESULTANTES.csv", "w+")

for num in lista_idNUEVOS:
	if num not in lista_id:
		f_new.write(num)

print("Se escribió el archivo")
f_new.close()