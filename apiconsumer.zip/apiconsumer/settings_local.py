# main settings configurations
apiKey = 'vMpn6xaE+BIpjA69f2m5Wyl+TK0UEOMK'
account = 'leonardo25_1@live.com'
APIURL = "http://api.plaspy.com/api/GetLocation"
LastPosition = False